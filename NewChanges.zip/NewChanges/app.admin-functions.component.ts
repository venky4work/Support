import {Component , OnInit} from '@angular/core'

@Component({
    selector:'admin-functions',
    templateUrl :`./app/admin/templates/app.admin-functions.html`
})
export class AdminFunctions implements OnInit{
    selectedFunction: string;
    constructor() {

    }
    ngOnInit(): void {
    
  }
    onSelectFunction(value: string): void {
    this.selectedFunction = value;
  }
}