import { NgModule } from '@angular/core'
import { RouterModule, Routes  } from '@angular/router'
import { AdminFunctions } from './admin/components/app.admin-functions.component'
import { BulkOperations } from './admin/components/app.bulk-operations.component'
import { AdminDashboard } from './shared/components/app.dashboard.component'


const routes: Routes = [
 {path: '', redirectTo: '/dashboard', pathMatch: 'full' },{path:'dashboard', component: AdminDashboard},{path: 'adminfunctions',
    component: AdminFunctions, }
];
@NgModule({
    imports:[         
        RouterModule.forRoot (routes)
        ] ,
    exports:[RouterModule ]
})
export class AppRoutingModule {

}